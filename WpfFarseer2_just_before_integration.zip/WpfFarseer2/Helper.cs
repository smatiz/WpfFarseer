﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfFarseer
{
     public class Const
     {
         public const float Density = 100f;
     }
    public class Helper
    {

    }
}
