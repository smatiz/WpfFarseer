﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReplaceExample
{
    public static class StaticClassB
    {
        public static void A()
        {
            Console.WriteLine("StaticClassB.A");
        }
        public static void B()
        {
            Console.WriteLine("StaticClassB.B");
        }
    }
}
