﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReplaceExample
{
    public static class StaticClassA
    {
        public static void A()
        {
            Console.WriteLine("StaticClassA.A");
        }
        public static void B()
        {
            Console.WriteLine("StaticClassA.B");
        }
    }
}
