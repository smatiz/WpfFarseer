﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReplaceExample
{
    public class InstanceClassA
    {
        public void A()
        {
            Console.WriteLine("InstanceClassA.A");
        }
        public void B()
        {
            Console.WriteLine("InstanceClassA.B");
        }
    }
}
