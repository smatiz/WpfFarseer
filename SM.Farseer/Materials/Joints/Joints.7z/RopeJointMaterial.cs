﻿using FarseerPhysics.Dynamics;
using FarseerPhysics.Dynamics.Joints;
using FarseerPhysics.Factories;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SM.Farseer
{
    public class RopeJointMaterial : BasicJointMaterial, IRopeJointMaterial
    {
        RopeJoint __joint;

        string _targetNameA;
        string _targetNameB;

        public RopeJointMaterial(World world, FarseerWorldManager farseerWorldManager)
            : base(world, farseerWorldManager)
        {
        }


        public void Build(string id)
        {
            _id = id;
            __joint = Build(
                _farseerWorldManager.FindObject<Body>(_targetNameA), _anchorA.ToFarseer(),
                _farseerWorldManager.FindObject<Body>(_targetNameB), _anchorB.ToFarseer());
            _joint = __joint;
        }

        RopeJoint Build(Body targetA, Vector2 anchorA, Body targetB, Vector2 anchorB)
        {
            return JointFactory.CreateRopeJoint(_world, targetA, targetB, anchorA, anchorB);
        }
        public string TargetNameA
        {
            get
            {
                return __joint.BodyA.UserData.ToString();
            }
            set
            {
                if (_joint != null)
                {
                    __joint.BodyA = _farseerWorldManager.FindObject<Body>(value);
                }
                else
                {
                    _targetNameA = value;
                }
            }
        }
        public string TargetNameB
        {
            get
            {
                return __joint.BodyB.UserData.ToString();
            }
            set
            {
                if (_joint != null)
                {
                    __joint.BodyB = _farseerWorldManager.FindObject<Body>(value);
                }
                else
                {
                    _targetNameB = value;
                }
            }
        }

        public float MaxLength
        {
            get
            {
                return __joint.MaxLength;
            }
            set
            {
                __joint.MaxLength = value;
            }
        }

    }
}
